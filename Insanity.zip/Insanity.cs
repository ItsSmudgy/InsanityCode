using Terraria.GameContent.UI;
using Terraria.ModLoader;

namespace Insanity
{
	public partial class Insanity : Mod
	{
	}	
}